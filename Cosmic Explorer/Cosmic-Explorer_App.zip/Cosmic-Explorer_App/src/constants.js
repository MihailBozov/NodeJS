const JWT_SECRET = 'SECRET';
const AUTH_COOKIE_NAME = 'auth';

export default { JWT_SECRET, AUTH_COOKIE_NAME };