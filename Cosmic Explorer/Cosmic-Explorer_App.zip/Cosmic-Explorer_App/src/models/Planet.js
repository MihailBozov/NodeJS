import { Schema, Types, model } from "mongoose";

const planetSchema = new Schema({
    name: {
        type: String,
        required: [true, 'The name is required!'],
        minLength: [2, 'The name should be at least 2 characters long'],

    },
    age: {
        type: Number,
        required: [true, 'The age is required'],
        min: [1, 'The age should be a positive number']
    },
    solarSystem: {
        type: String,
        required: [true, 'The solar system is required'],
        minLength: [2, 'The solar system name should be at least 2 characters long'],
    },
    type: {
        type: String,
        enum: ['Inner', 'Outer', 'Dwarf'],
        required: [true, , 'The type is required']
    },
    moons: {
        type: Number,
        required: [true, 'The moons number is required'],
        min: [1, 'The number of moons should be a positive number']
        
    },
    size: {
        type: Number,
        required: [true, 'The planet size is required'],
        min: [0.1, 'The size of the planet should be a positive number']
        
    },
    rings: {
        type: String,
        enum: ['Yes', 'No'],
        required: [true, 'The planet rings are required'],
    },
    description: {
        type: String,
        required: [true, 'The description is required'],
        minLength: [2, 'The description should be at least 10 characters long'],
        maxLength: [100, 'The description should be up to 100 characters long']
    },
    image: {
        type: String,
        required: [true, 'The image is required'],
        match: [/^https?:\/\/.+/, 'The image address should start with "http://" or "https://"']
    },
    likedList: [{
        type: Types.ObjectId,
        ref: 'User',
    }],
    owner: {
        type: Types.ObjectId,
        ref: 'User',
    }
})

 const Planet = model('Planet', planetSchema);
 export default Planet;

