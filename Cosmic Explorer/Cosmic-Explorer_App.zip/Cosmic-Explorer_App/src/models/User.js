import { Schema, model } from "mongoose";
import bcrypt from 'bcrypt';

const UserSchema = new Schema({
    username: {
        type: String,
        required: [true, 'The username is required!'],
        unique: [true, 'The username is already present in the database'],
        minLength: [2, 'The username should be at least 2 characters long'],
        maxLength: [20, 'The username should be up to 20 characters long']
    },
    email: {
        type: String,
        required: [true, 'The email is required!'],
        minLength: [10, 'The email should be at least 10 characters long']
    },
    password: {
        type: String, 
        required: [true, 'The password is required!'],
        minLength: [4, 'The password should be at least 4 characters long']
    }
});

UserSchema.pre('save', async function() {
    const hashedPassword = await bcrypt.hash(this.password, 10);
    this.password = hashedPassword;
})

const User = model('User', UserSchema)

export default User;