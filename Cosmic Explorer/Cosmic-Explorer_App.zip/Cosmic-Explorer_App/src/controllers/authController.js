import { Router } from 'express';
import authService from '../services/authService.js';
import { getErrorMessage } from '../utils/errorUtil.js';
import constants from '../constants.js';
import { isAuthenticated, isNotAuthenticated } from '../middlewares/authMiddleware.js';

const authController = Router();

authController.get('/register', isNotAuthenticated, (req, res) => {
    res.render('auth/register', { tittle: 'Register' })
})

authController.post('/register', isNotAuthenticated, async (req, res) => {
    const user = Object.assign({}, req.body);
    try {
        const token = await authService.registerUser(user);
        res.cookie(constants.AUTH_COOKIE_NAME, token, { httpOnly: true })
        res.redirect('/');
    } catch (err) {
        const error = getErrorMessage(err);
        res.render('auth/register', { tittle: 'Register', user, error });
    }
})

authController.get('/login', isNotAuthenticated, (req, res) => {
    res.render('auth/login', { tittle: 'Login' })
});

authController.post('/login', isNotAuthenticated, async (req, res) => {
    const user = Object.assign({}, req.body);
    try {
        const token = await authService.loginUser(user);
        res.cookie(constants.AUTH_COOKIE_NAME, token, { httpOnly: true });
        res.redirect('/');
    } catch (err) {
        const error = getErrorMessage(err);
        res.render('auth/login', { tittle: 'Login', username: user.username, error })
    }
})

authController.get('/logout', isAuthenticated, (req, res) => {
    res.clearCookie(constants.AUTH_COOKIE_NAME);
    res.redirect('/')
})



export default authController;