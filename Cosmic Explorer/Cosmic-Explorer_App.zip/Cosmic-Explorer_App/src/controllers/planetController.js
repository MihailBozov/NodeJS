import { Router } from "express";
import { getErrorMessage } from '../utils/errorUtil.js';
import planetService from "../services/planetService.js";
import { isAuthenticated, isNotPlanetOwner, isPlanetOwner } from "../middlewares/authMiddleware.js";

const planetController = Router();

planetController.get('/all', async (req, res) => {
    const planets = await planetService.findAllPlanets();
    res.render('planets/catalog', {  tittle: 'Planet Catalog', planets })
})

planetController.get('/create', isAuthenticated, (req, res) => {
    res.render('planets/create', { tittle: 'Add New Planet' });
});

planetController.post('/create', isAuthenticated, async (req, res) => {
    const planet = Object.assign({}, req.body);
    const userId = req.user._id;

    try {
        const newPlanet = await planetService.createPlanet(planet, userId);
        res.redirect('/');

    } catch (err) {
        const error = getErrorMessage(err);
        res.render('planets/create', { tittle: 'Create a planet', planet, error })
    }
});


planetController.get('/:id/details', async (req, res) => {
    const planetId = req.params.id;
    const userId = req.user?._id;
    const planet = await planetService.findPlanetById(planetId);
    const isOwner = planet?.owner.toString() === userId;
    const hasLiked = await planetService.hasLiked(planetId, userId)

    res.render('planets/details', { tittle: 'Planet Details', planet, isOwner, hasLiked })
})

planetController.get('/:id/edit', isAuthenticated, isPlanetOwner, async (req, res) => {
    const id = req.params.id;
    const planet = await planetService.findPlanetById(id);
    res.render('planets/edit', { tittle: 'Edit Planet', planet })
})

planetController.post('/:id/edit', isAuthenticated, isPlanetOwner, async (req, res) => {
    const id = req.params.id;
    const planet = Object.assign({}, req.body);
    try {
        await planetService.editPlanet(id, planet);
        res.redirect(`/planets/${id}/details`)

    } catch (err) {
        const error = getErrorMessage(err);
        res.render(`planets/edit`, { tittle: 'Edit Page', planet, error });
    }
})

planetController.get('/:id/like', isAuthenticated, isNotPlanetOwner, async (req, res) => {
    const planetId = req.params.id;
    const userId = req.user._id;

    const result = await planetService.like(planetId, userId);
    res.redirect(`/planets/${planetId}/details`);

})

planetController.get('/:id/delete', isAuthenticated, isPlanetOwner, async (req, res) => {
    const id = req.params.id;
    await planetService.deletePlanet(id);
    res.redirect('/planets/all')
})

planetController.get('/search', async (req, res) => {
    const filter = Object.assign({}, req.query);
    const planets = await planetService.findAllPlanetsFiltered(filter);
    res.render('planets/search', { tittle: 'Planet Search', planets, filter });
})


export default planetController