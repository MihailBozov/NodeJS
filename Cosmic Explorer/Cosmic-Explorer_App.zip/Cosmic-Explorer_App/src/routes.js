import { Router } from "express";
import homeController from "./controllers/homeController.js";
import authController from "./controllers/authController.js";
import planetController from "./controllers/planetController.js";

const router = Router();

router.use(homeController);
router.use('/auth', authController);
router.use('/planets', planetController);

router.all('*', (req, res) => {
    res.render('404', {tittle: '404 - Page Not Found'});
});


export default router;