import Planet from '../models/Planet.js';


async function createPlanet(planet, userId) {
    return await Planet.create({ ...planet, owner: userId });
}

async function findAllPlanets() {
    return await Planet.find().lean();
}

async function findPlanetById(id) {
    return await Planet.findById(id).lean();
}

async function findAllPlanetsFiltered(filter) {

    const name = filter?.name || '';
    const solarSystem = filter?.solarSystem || '';

    let planets = await Planet.find({ name: { $regex: name, $options: 'i' }, solarSystem: { $regex: solarSystem, $options: 'i' } }).lean();

    return planets;
}

async function deletePlanet(id) {
    await Planet.findByIdAndDelete(id);
}

async function editPlanet(id, editedPlanet) {
    const planetDb = await Planet.findByIdAndUpdate(id, editedPlanet, { runValidators: true });
}

async function like(planetId, userId) {
    const planet = await Planet.findById(planetId);
    const likedPlanetList = planet?.likedList;

    if (likedPlanetList.includes(userId)) {
        return false;
    }

    likedPlanetList.push(userId);
    planet.likedList = likedPlanetList;
    await planet.save();
    return true;
}

async function hasLiked(planetId, userId) {
    const planet = await Planet.findById(planetId);
    return planet?.likedList.includes(userId)
}

export default { createPlanet, findAllPlanets, findPlanetById, findAllPlanetsFiltered, deletePlanet, editPlanet, hasLiked, like };