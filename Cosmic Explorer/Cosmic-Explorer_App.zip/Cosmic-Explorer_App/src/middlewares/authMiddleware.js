import jwt from 'jsonwebtoken'
import constants from '../constants.js';
import planetService from '../services/planetService.js';

export async function authMiddleware(req, res, next) {
    const token = req.cookies[constants.AUTH_COOKIE_NAME];
    if (!token) {
        return next();
    }

    try {
        const decodedUser = await jwt.verify(token, constants.JWT_SECRET);

        req.user = decodedUser;
        res.locals.user = decodedUser;
        res.locals.isAuthenticated = true;
        
        return  next();
    } catch (err) {
        res.clearCookie(constants.AUTH_COOKIE_NAME);
        res.redirect('/auth/login');
    }
}

export function isAuthenticated(req, res, next) {
    if (!req.user) {
        return res.redirect('/auth/login')
    }

   return next();
}

export function isNotAuthenticated(req, res, next) {
    if (req.user) {
        return res.redirect('/');
    }
    
    return next();
}

export async function isPlanetOwner(req, res, next) {
    const planetId = req.params?.id;
    const userId = req.user?._id;

    if (!planetId || !userId) {
        return res.redirect(`/planets/${planetId}/details`)
    }

    const planet = await planetService.findPlanetById(planetId);
    const ownerId = planet?.owner.toString();

    if (userId === ownerId) {
        return next();
    }
    
    return res.redirect(`/planets/${planetId}/details`)
}

export async function isNotPlanetOwner(req, res, next) {
    const planetId = req.params?.id;
    const userId = req.user?._id;
    
    if(!planetId, !userId) {
        return next();
    }
    
    const planet = await planetService.findPlanetById(planetId);
    const ownerId = planet?.owner.toString()
    
    if(ownerId !== userId) {
        return next()
    }
    
    return res.redirect(`planets/${planetId}/details`);
}